﻿namespace AppSimProva_Bianca_2B1
{
    partial class FrmQuestao1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.pnlProdutos = new System.Windows.Forms.Panel();
            this.lblProduto1 = new System.Windows.Forms.Label();
            this.txtProduto1 = new System.Windows.Forms.TextBox();
            this.txtProduto2 = new System.Windows.Forms.TextBox();
            this.txtProduto3 = new System.Windows.Forms.TextBox();
            this.lblProduto2 = new System.Windows.Forms.Label();
            this.lblProduto3 = new System.Windows.Forms.Label();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.PnlResultados = new System.Windows.Forms.Panel();
            this.lblParcela1 = new System.Windows.Forms.Label();
            this.lblParcela2 = new System.Windows.Forms.Label();
            this.lblParcela3 = new System.Windows.Forms.Label();
            this.lblParcela4 = new System.Windows.Forms.Label();
            this.lblParcela5 = new System.Windows.Forms.Label();
            this.lblR1 = new System.Windows.Forms.Label();
            this.lblR2 = new System.Windows.Forms.Label();
            this.lblR3 = new System.Windows.Forms.Label();
            this.lblR4 = new System.Windows.Forms.Label();
            this.lblR5 = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTitulo.SuspendLayout();
            this.pnlProdutos.SuspendLayout();
            this.PnlResultados.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(235)))), ((int)(((byte)(202)))));
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(0, -4);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(809, 83);
            this.pnlTitulo.TabIndex = 0;
            // 
            // pnlProdutos
            // 
            this.pnlProdutos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(235)))), ((int)(((byte)(202)))));
            this.pnlProdutos.Controls.Add(this.txtPreco3);
            this.pnlProdutos.Controls.Add(this.txtPreco2);
            this.pnlProdutos.Controls.Add(this.txtPreco1);
            this.pnlProdutos.Controls.Add(this.lblPreco3);
            this.pnlProdutos.Controls.Add(this.lblPreco2);
            this.pnlProdutos.Controls.Add(this.lblPreco1);
            this.pnlProdutos.Controls.Add(this.lblProduto3);
            this.pnlProdutos.Controls.Add(this.lblProduto2);
            this.pnlProdutos.Controls.Add(this.txtProduto3);
            this.pnlProdutos.Controls.Add(this.txtProduto2);
            this.pnlProdutos.Controls.Add(this.txtProduto1);
            this.pnlProdutos.Controls.Add(this.lblProduto1);
            this.pnlProdutos.Location = new System.Drawing.Point(12, 100);
            this.pnlProdutos.Name = "pnlProdutos";
            this.pnlProdutos.Size = new System.Drawing.Size(369, 282);
            this.pnlProdutos.TabIndex = 1;
            // 
            // lblProduto1
            // 
            this.lblProduto1.AutoSize = true;
            this.lblProduto1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto1.Location = new System.Drawing.Point(28, 24);
            this.lblProduto1.Name = "lblProduto1";
            this.lblProduto1.Size = new System.Drawing.Size(70, 20);
            this.lblProduto1.TabIndex = 0;
            this.lblProduto1.Text = "Produto 1";

            // 
            // txtProduto1
            // 
            this.txtProduto1.Location = new System.Drawing.Point(31, 58);
            this.txtProduto1.Name = "txtProduto1";
            this.txtProduto1.Size = new System.Drawing.Size(100, 20);
            this.txtProduto1.TabIndex = 3;
            // 
            // txtProduto2
            // 
            this.txtProduto2.Location = new System.Drawing.Point(32, 150);
            this.txtProduto2.Name = "txtProduto2";
            this.txtProduto2.Size = new System.Drawing.Size(100, 20);
            this.txtProduto2.TabIndex = 4;
            // 
            // txtProduto3
            // 
            this.txtProduto3.Location = new System.Drawing.Point(31, 229);
            this.txtProduto3.Name = "txtProduto3";
            this.txtProduto3.Size = new System.Drawing.Size(100, 20);
            this.txtProduto3.TabIndex = 5;
           // this.txtProduto3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lblProduto2
            // 
            this.lblProduto2.AutoSize = true;
            this.lblProduto2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto2.Location = new System.Drawing.Point(28, 108);
            this.lblProduto2.Name = "lblProduto2";
            this.lblProduto2.Size = new System.Drawing.Size(70, 20);
            this.lblProduto2.TabIndex = 6;
            this.lblProduto2.Text = "Produto 2";
            // 
            // lblProduto3
            // 
            this.lblProduto3.AutoSize = true;
            this.lblProduto3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto3.Location = new System.Drawing.Point(28, 189);
            this.lblProduto3.Name = "lblProduto3";
            this.lblProduto3.Size = new System.Drawing.Size(70, 20);
            this.lblProduto3.TabIndex = 7;
            this.lblProduto3.Text = "Produto 3";
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco1.Location = new System.Drawing.Point(229, 24);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(56, 20);
            this.lblPreco1.TabIndex = 2;
            this.lblPreco1.Text = "Preço 1";
            //this.lblPreco1.Click += new System.EventHandler(this.lblPreco1_Click);
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco2.Location = new System.Drawing.Point(229, 108);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(56, 20);
            this.lblPreco2.TabIndex = 8;
            this.lblPreco2.Text = "Preço 2";
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco3.Location = new System.Drawing.Point(229, 189);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(56, 20);
            this.lblPreco3.TabIndex = 9;
            this.lblPreco3.Text = "Preço 3";
            // 
            // txtPreco1
            // 
            this.txtPreco1.Location = new System.Drawing.Point(233, 58);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(100, 20);
            this.txtPreco1.TabIndex = 10;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(233, 150);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(100, 20);
            this.txtPreco2.TabIndex = 11;
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(233, 229);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(100, 20);
            this.txtPreco3.TabIndex = 12;
            // 
            // PnlResultados
            // 
            this.PnlResultados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(235)))), ((int)(((byte)(202)))));
            this.PnlResultados.Controls.Add(this.lblR5);
            this.PnlResultados.Controls.Add(this.lblR4);
            this.PnlResultados.Controls.Add(this.lblR3);
            this.PnlResultados.Controls.Add(this.lblR2);
            this.PnlResultados.Controls.Add(this.lblR1);
            this.PnlResultados.Controls.Add(this.lblParcela5);
            this.PnlResultados.Controls.Add(this.lblParcela4);
            this.PnlResultados.Controls.Add(this.lblParcela3);
            this.PnlResultados.Controls.Add(this.lblParcela2);
            this.PnlResultados.Controls.Add(this.lblParcela1);
            this.PnlResultados.Location = new System.Drawing.Point(406, 100);
            this.PnlResultados.Name = "PnlResultados";
            this.PnlResultados.Size = new System.Drawing.Size(233, 282);
            this.PnlResultados.TabIndex = 2;
            // 
            // lblParcela1
            // 
            this.lblParcela1.AutoSize = true;
            this.lblParcela1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela1.Location = new System.Drawing.Point(34, 38);
            this.lblParcela1.Name = "lblParcela1";
            this.lblParcela1.Size = new System.Drawing.Size(66, 20);
            this.lblParcela1.TabIndex = 13;
            this.lblParcela1.Text = "Parcela 1";
            // 
            // lblParcela2
            // 
            this.lblParcela2.AutoSize = true;
            this.lblParcela2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela2.Location = new System.Drawing.Point(34, 82);
            this.lblParcela2.Name = "lblParcela2";
            this.lblParcela2.Size = new System.Drawing.Size(66, 20);
            this.lblParcela2.TabIndex = 14;
            this.lblParcela2.Text = "Parcela 2";
            // 
            // lblParcela3
            // 
            this.lblParcela3.AutoSize = true;
            this.lblParcela3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela3.Location = new System.Drawing.Point(34, 130);
            this.lblParcela3.Name = "lblParcela3";
            this.lblParcela3.Size = new System.Drawing.Size(66, 20);
            this.lblParcela3.TabIndex = 15;
            this.lblParcela3.Text = "Parcela 3";
            // 
            // lblParcela4
            // 
            this.lblParcela4.AutoSize = true;
            this.lblParcela4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela4.Location = new System.Drawing.Point(34, 180);
            this.lblParcela4.Name = "lblParcela4";
            this.lblParcela4.Size = new System.Drawing.Size(66, 20);
            this.lblParcela4.TabIndex = 16;
            this.lblParcela4.Text = "Parcela 4";
            // 
            // lblParcela5
            // 
            this.lblParcela5.AutoSize = true;
            this.lblParcela5.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela5.Location = new System.Drawing.Point(34, 227);
            this.lblParcela5.Name = "lblParcela5";
            this.lblParcela5.Size = new System.Drawing.Size(66, 20);
            this.lblParcela5.TabIndex = 17;
            this.lblParcela5.Text = "Parcela 5";
            // 
            // lblR1
            // 
            this.lblR1.AutoSize = true;
            this.lblR1.Location = new System.Drawing.Point(156, 45);
            this.lblR1.Name = "lblR1";
            this.lblR1.Size = new System.Drawing.Size(10, 13);
            this.lblR1.TabIndex = 18;
            this.lblR1.Text = "-";
            // 
            // lblR2
            // 
            this.lblR2.AutoSize = true;
            this.lblR2.Location = new System.Drawing.Point(156, 87);
            this.lblR2.Name = "lblR2";
            this.lblR2.Size = new System.Drawing.Size(10, 13);
            this.lblR2.TabIndex = 19;
            this.lblR2.Text = "-";
            // 
            // lblR3
            // 
            this.lblR3.AutoSize = true;
            this.lblR3.Location = new System.Drawing.Point(156, 135);
            this.lblR3.Name = "lblR3";
            this.lblR3.Size = new System.Drawing.Size(10, 13);
            this.lblR3.TabIndex = 20;
            this.lblR3.Text = "-";
            // 
            // lblR4
            // 
            this.lblR4.AutoSize = true;
            this.lblR4.Location = new System.Drawing.Point(156, 185);
            this.lblR4.Name = "lblR4";
            this.lblR4.Size = new System.Drawing.Size(10, 13);
            this.lblR4.TabIndex = 21;
            this.lblR4.Text = "-";
            // 
            // lblR5
            // 
            this.lblR5.AutoSize = true;
            this.lblR5.Location = new System.Drawing.Point(156, 232);
            this.lblR5.Name = "lblR5";
            this.lblR5.Size = new System.Drawing.Size(10, 13);
            this.lblR5.TabIndex = 22;
            this.lblR5.Text = "-";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(37, 25);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(246, 37);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Loja de Games";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(235)))), ((int)(((byte)(202)))));
            this.btnCalcular.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(659, 187);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(128, 63);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuestao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 413);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.PnlResultados);
            this.Controls.Add(this.pnlProdutos);
            this.Controls.Add(this.pnlTitulo);
            this.Name = "FrmQuestao1";
            this.Text = "Questão 1";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlProdutos.ResumeLayout(false);
            this.pnlProdutos.PerformLayout();
            this.PnlResultados.ResumeLayout(false);
            this.PnlResultados.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Panel pnlProdutos;
        private System.Windows.Forms.TextBox txtProduto3;
        private System.Windows.Forms.TextBox txtProduto2;
        private System.Windows.Forms.TextBox txtProduto1;
        private System.Windows.Forms.Label lblProduto1;
        private System.Windows.Forms.Label lblProduto3;
        private System.Windows.Forms.Label lblProduto2;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.Panel PnlResultados;
        private System.Windows.Forms.Label lblParcela2;
        private System.Windows.Forms.Label lblParcela1;
        private System.Windows.Forms.Label lblParcela5;
        private System.Windows.Forms.Label lblParcela4;
        private System.Windows.Forms.Label lblParcela3;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblR5;
        private System.Windows.Forms.Label lblR4;
        private System.Windows.Forms.Label lblR3;
        private System.Windows.Forms.Label lblR2;
        private System.Windows.Forms.Label lblR1;
        private System.Windows.Forms.Button btnCalcular;
    }
}

