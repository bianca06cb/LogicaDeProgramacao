﻿namespace AppTestePratico_Bianca
{
    partial class FrmQuetao1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuetao1));
            this.pnlSuperior = new System.Windows.Forms.Panel();
            this.lblQuetao1 = new System.Windows.Forms.Label();
            this.pnlInferior = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblValorPagar = new System.Windows.Forms.Label();
            this.lblQtdPaes = new System.Windows.Forms.Label();
            this.lblQtdBroa = new System.Windows.Forms.Label();
            this.txtPaes = new System.Windows.Forms.TextBox();
            this.txtBroa = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlSuperior.SuspendLayout();
            this.pnlInferior.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSuperior
            // 
            this.pnlSuperior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(19)))), ((int)(((byte)(48)))));
            this.pnlSuperior.Controls.Add(this.lblQuetao1);
            this.pnlSuperior.Location = new System.Drawing.Point(1, 1);
            this.pnlSuperior.Name = "pnlSuperior";
            this.pnlSuperior.Size = new System.Drawing.Size(801, 81);
            this.pnlSuperior.TabIndex = 0;
            // 
            // lblQuetao1
            // 
            this.lblQuetao1.AutoSize = true;
            this.lblQuetao1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(19)))), ((int)(((byte)(48)))));
            this.lblQuetao1.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuetao1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblQuetao1.Location = new System.Drawing.Point(23, 21);
            this.lblQuetao1.Name = "lblQuetao1";
            this.lblQuetao1.Size = new System.Drawing.Size(190, 41);
            this.lblQuetao1.TabIndex = 0;
            this.lblQuetao1.Text = "Questão 1";
            // 
            // pnlInferior
            // 
            this.pnlInferior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(19)))), ((int)(((byte)(48)))));
            this.pnlInferior.Controls.Add(this.lblResultado);
            this.pnlInferior.Controls.Add(this.lblValorPagar);
            this.pnlInferior.Location = new System.Drawing.Point(1, 360);
            this.pnlInferior.Name = "pnlInferior";
            this.pnlInferior.Size = new System.Drawing.Size(801, 89);
            this.pnlInferior.TabIndex = 1;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(19)))), ((int)(((byte)(48)))));
            this.lblResultado.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblResultado.Location = new System.Drawing.Point(327, 25);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 41);
            this.lblResultado.TabIndex = 2;
            // 
            // lblValorPagar
            // 
            this.lblValorPagar.AutoSize = true;
            this.lblValorPagar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(19)))), ((int)(((byte)(48)))));
            this.lblValorPagar.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorPagar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblValorPagar.Location = new System.Drawing.Point(25, 25);
            this.lblValorPagar.Name = "lblValorPagar";
            this.lblValorPagar.Size = new System.Drawing.Size(263, 41);
            this.lblValorPagar.TabIndex = 1;
            this.lblValorPagar.Text = "Valor a pagar:";
            // 
            // lblQtdPaes
            // 
            this.lblQtdPaes.AutoSize = true;
            this.lblQtdPaes.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdPaes.Location = new System.Drawing.Point(26, 107);
            this.lblQtdPaes.Name = "lblQtdPaes";
            this.lblQtdPaes.Size = new System.Drawing.Size(223, 25);
            this.lblQtdPaes.TabIndex = 2;
            this.lblQtdPaes.Text = "Quantidade de Pães";
            // 
            // lblQtdBroa
            // 
            this.lblQtdBroa.AutoSize = true;
            this.lblQtdBroa.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdBroa.Location = new System.Drawing.Point(28, 187);
            this.lblQtdBroa.Name = "lblQtdBroa";
            this.lblQtdBroa.Size = new System.Drawing.Size(221, 25);
            this.lblQtdBroa.TabIndex = 3;
            this.lblQtdBroa.Text = "Quantidade de Broa";
            // 
            // txtPaes
            // 
            this.txtPaes.Location = new System.Drawing.Point(44, 148);
            this.txtPaes.Name = "txtPaes";
            this.txtPaes.Size = new System.Drawing.Size(187, 20);
            this.txtPaes.TabIndex = 4;
            // 
            // txtBroa
            // 
            this.txtBroa.Location = new System.Drawing.Point(44, 241);
            this.txtBroa.Name = "txtBroa";
            this.txtBroa.Size = new System.Drawing.Size(187, 20);
            this.txtBroa.TabIndex = 5;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(19)))), ((int)(((byte)(48)))));
            this.btnCalcular.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.SystemColors.Window;
            this.btnCalcular.Location = new System.Drawing.Point(306, 160);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(123, 52);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuetao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtBroa);
            this.Controls.Add(this.txtPaes);
            this.Controls.Add(this.lblQtdBroa);
            this.Controls.Add(this.lblQtdPaes);
            this.Controls.Add(this.pnlInferior);
            this.Controls.Add(this.pnlSuperior);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuetao1";
            this.Text = "Questão1";
            this.pnlSuperior.ResumeLayout(false);
            this.pnlSuperior.PerformLayout();
            this.pnlInferior.ResumeLayout(false);
            this.pnlInferior.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSuperior;
        private System.Windows.Forms.Label lblQuetao1;
        private System.Windows.Forms.Panel pnlInferior;
        private System.Windows.Forms.Label lblQtdPaes;
        private System.Windows.Forms.Label lblQtdBroa;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblValorPagar;
        private System.Windows.Forms.TextBox txtPaes;
        private System.Windows.Forms.TextBox txtBroa;
        private System.Windows.Forms.Button btnCalcular;
    }
}

