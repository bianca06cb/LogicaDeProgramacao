﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Bianca
{
    public partial class FrmQuetao1 : Form
    {
        public FrmQuetao1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int qtdPaes = int.Parse(txtPaes.Text);
            int qtdBroa = int.Parse(txtBroa.Text);
            float total;

            //Fazer Cálculo
            total = qtdPaes * 0.12f + qtdBroa * 1.50f;

            //Mostrar o resultado em uma label
            lblResultado.Text = "R$" + total;
        }
    }
}
