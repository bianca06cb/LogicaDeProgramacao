﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Bianca
{
    public partial class FrmQuestao2 : Form
    {
        public FrmQuestao2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int qtdCamisasP = int.Parse(txtCamisasP.Text);
            int qtdCamisasM = int.Parse(txtCamisasM.Text);
            int qtdCamisasG = int.Parse(txtCamisasG.Text);
            float total;

            //Fazer Cálculo
            total = qtdCamisasP * 12 + qtdCamisasM * 14 + qtdCamisasG * 22;

            //Mostrar o resultado em uma label
            lblResultado.Text = "R$" + total;
        }
    }
    }
    }
}
