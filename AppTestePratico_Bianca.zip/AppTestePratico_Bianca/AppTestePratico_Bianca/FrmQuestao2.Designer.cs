﻿namespace AppTestePratico_Bianca
{
    partial class FrmQuestao2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlSuperior = new System.Windows.Forms.Panel();
            this.pnlInferior = new System.Windows.Forms.Panel();
            this.lblQuetao2 = new System.Windows.Forms.Label();
            this.lblQtdCmisasP = new System.Windows.Forms.Label();
            this.lblQtdCmisasM = new System.Windows.Forms.Label();
            this.lblQtdCmisasG = new System.Windows.Forms.Label();
            this.txtCamisasP = new System.Windows.Forms.TextBox();
            this.txtCamisasM = new System.Windows.Forms.TextBox();
            this.txtCamisasG = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValorPagar = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlSuperior.SuspendLayout();
            this.pnlInferior.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlSuperior
            // 
            this.pnlSuperior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(160)))), ((int)(((byte)(123)))));
            this.pnlSuperior.Controls.Add(this.lblQuetao2);
            this.pnlSuperior.Location = new System.Drawing.Point(-2, 0);
            this.pnlSuperior.Name = "pnlSuperior";
            this.pnlSuperior.Size = new System.Drawing.Size(805, 84);
            this.pnlSuperior.TabIndex = 0;
            // 
            // pnlInferior
            // 
            this.pnlInferior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(160)))), ((int)(((byte)(123)))));
            this.pnlInferior.Controls.Add(this.lblResultado);
            this.pnlInferior.Controls.Add(this.lblValorPagar);
            this.pnlInferior.Location = new System.Drawing.Point(-2, 377);
            this.pnlInferior.Name = "pnlInferior";
            this.pnlInferior.Size = new System.Drawing.Size(805, 72);
            this.pnlInferior.TabIndex = 1;
            // 
            // lblQuetao2
            // 
            this.lblQuetao2.AutoSize = true;
            this.lblQuetao2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(160)))), ((int)(((byte)(123)))));
            this.lblQuetao2.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuetao2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblQuetao2.Location = new System.Drawing.Point(23, 21);
            this.lblQuetao2.Name = "lblQuetao2";
            this.lblQuetao2.Size = new System.Drawing.Size(190, 41);
            this.lblQuetao2.TabIndex = 1;
            this.lblQuetao2.Text = "Questão 2";
            // 
            // lblQtdCmisasP
            // 
            this.lblQtdCmisasP.AutoSize = true;
            this.lblQtdCmisasP.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCmisasP.Location = new System.Drawing.Point(23, 112);
            this.lblQtdCmisasP.Name = "lblQtdCmisasP";
            this.lblQtdCmisasP.Size = new System.Drawing.Size(277, 25);
            this.lblQtdCmisasP.TabIndex = 3;
            this.lblQtdCmisasP.Text = "Quantidade de camisas P";
            // 
            // lblQtdCmisasM
            // 
            this.lblQtdCmisasM.AutoSize = true;
            this.lblQtdCmisasM.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCmisasM.Location = new System.Drawing.Point(23, 191);
            this.lblQtdCmisasM.Name = "lblQtdCmisasM";
            this.lblQtdCmisasM.Size = new System.Drawing.Size(284, 25);
            this.lblQtdCmisasM.TabIndex = 4;
            this.lblQtdCmisasM.Text = "Quantidade de camisas M";
            // 
            // lblQtdCmisasG
            // 
            this.lblQtdCmisasG.AutoSize = true;
            this.lblQtdCmisasG.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCmisasG.Location = new System.Drawing.Point(23, 278);
            this.lblQtdCmisasG.Name = "lblQtdCmisasG";
            this.lblQtdCmisasG.Size = new System.Drawing.Size(283, 25);
            this.lblQtdCmisasG.TabIndex = 5;
            this.lblQtdCmisasG.Text = "Quantidade de camisas G";
            // 
            // txtCamisasP
            // 
            this.txtCamisasP.Location = new System.Drawing.Point(55, 154);
            this.txtCamisasP.Name = "txtCamisasP";
            this.txtCamisasP.Size = new System.Drawing.Size(187, 20);
            this.txtCamisasP.TabIndex = 6;
            // 
            // txtCamisasM
            // 
            this.txtCamisasM.Location = new System.Drawing.Point(55, 240);
            this.txtCamisasM.Name = "txtCamisasM";
            this.txtCamisasM.Size = new System.Drawing.Size(187, 20);
            this.txtCamisasM.TabIndex = 7;
            // 
            // txtCamisasG
            // 
            this.txtCamisasG.Location = new System.Drawing.Point(55, 326);
            this.txtCamisasG.Name = "txtCamisasG";
            this.txtCamisasG.Size = new System.Drawing.Size(187, 20);
            this.txtCamisasG.TabIndex = 8;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(160)))), ((int)(((byte)(123)))));
            this.btnCalcular.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.SystemColors.Window;
            this.btnCalcular.Location = new System.Drawing.Point(339, 199);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(123, 52);
            this.btnCalcular.TabIndex = 9;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValorPagar
            // 
            this.lblValorPagar.AutoSize = true;
            this.lblValorPagar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(160)))), ((int)(((byte)(123)))));
            this.lblValorPagar.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorPagar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblValorPagar.Location = new System.Drawing.Point(23, 10);
            this.lblValorPagar.Name = "lblValorPagar";
            this.lblValorPagar.Size = new System.Drawing.Size(263, 41);
            this.lblValorPagar.TabIndex = 2;
            this.lblValorPagar.Text = "Valor a pagar:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(160)))), ((int)(((byte)(123)))));
            this.lblResultado.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblResultado.Location = new System.Drawing.Point(292, 10);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 41);
            this.lblResultado.TabIndex = 3;
            // 
            // FrmQuestao2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtCamisasG);
            this.Controls.Add(this.txtCamisasM);
            this.Controls.Add(this.txtCamisasP);
            this.Controls.Add(this.lblQtdCmisasG);
            this.Controls.Add(this.lblQtdCmisasM);
            this.Controls.Add(this.lblQtdCmisasP);
            this.Controls.Add(this.pnlInferior);
            this.Controls.Add(this.pnlSuperior);
            this.Name = "FrmQuestao2";
            this.Text = "FrmQuestao2";
            this.pnlSuperior.ResumeLayout(false);
            this.pnlSuperior.PerformLayout();
            this.pnlInferior.ResumeLayout(false);
            this.pnlInferior.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlSuperior;
        private System.Windows.Forms.Panel pnlInferior;
        private System.Windows.Forms.Label lblQuetao2;
        private System.Windows.Forms.Label lblQtdCmisasP;
        private System.Windows.Forms.Label lblQtdCmisasM;
        private System.Windows.Forms.Label lblQtdCmisasG;
        private System.Windows.Forms.TextBox txtCamisasP;
        private System.Windows.Forms.TextBox txtCamisasM;
        private System.Windows.Forms.TextBox txtCamisasG;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValorPagar;
        private System.Windows.Forms.Label lblResultado;
    }
}